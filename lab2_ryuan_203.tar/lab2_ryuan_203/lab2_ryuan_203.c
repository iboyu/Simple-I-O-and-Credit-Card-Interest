#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#define SIZE 50
#define n 12

int main(){
	char inBuf[SIZE];
	double oriSum, newSum, apr, newApr, numOfDaysInYear, interest;
	int numOfDays;

	printf("Enter a value for the amount of expenses of the CC: ");
	fgets(inBuf, SIZE, stdin);
	sscanf(inBuf, "%lf", &oriSum);
	if(oriSum < 0){
	printf("%.2lf is an invalid input. The amount of expenses cannot be negative.", oriSum);
	exit (-1);
	}
	
	printf("Enter a value for the Annual Percentage Rate: ");
	fgets(inBuf, SIZE, stdin);
	sscanf(inBuf, "%lf", &apr);
	if(apr < 0){
		printf("%.2lf is an invalid input. The APR amount cannot be negative.", apr);
		exit (-1);
	}
	newApr = apr / 100;

	printf("Enter the number of days money is borrowed: ");
	fgets(inBuf, SIZE, stdin);
	sscanf(inBuf, "%d", &numOfDays);
	if(numOfDays < 0){
		printf("%d is an invalid input. The number of days cannot be negative.", numOfDays);
		exit (-1);
	}
	numOfDaysInYear = (double)numOfDays / 365;

	newSum = oriSum * pow((1 + newApr / n), n* numOfDaysInYear);
	
	interest = newSum - oriSum;

	printf("Expense amount: %.lf\n", oriSum);
	printf("APR: %.2lf\n",apr);
	printf("Number of days: %d\n", numOfDays);
	printf("Amount of interest: %.2lf\n", interest);
	printf("Total amount to be paid back: %.2lf\n", newSum);


	return 0;
}
